package com.example.ejerciciologin;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    private Button btnacceder;
    String nombre= "Marisol Tolentino", usuario ="Marichiquitabb", contrasena="19590330";
    private EditText login, pass;

    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        login = findViewById(R.id.usuario);
        pass = findViewById(R.id.contrasena);
    }

     public void validar(View view){
         Intent saludo= new Intent(MainActivity.this, Ingreso.class);
         Intent fallo=new Intent(MainActivity.this, Registro.class);
         String l=login.getText().toString();
         String p=pass.getText().toString();
         if(l.equals(usuario)&& p.equals(contrasena)){
             saludo.putExtra("Nombre",nombre);
             startActivity(saludo);
         }
         else {
             startActivity(fallo);
         }

        }

}
