package com.example.basededatos;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText ncontrol, name, semester, career;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ncontrol = findViewById(R.id.ncontrol);
        name = findViewById(R.id.name);
        semester = findViewById(R.id.semester);
        career = findViewById(R.id.career);
    }

    public void alta(View view) {
        AdminSQLiteOpenHelper admin = new
                AdminSQLiteOpenHelper(this, "administracion", null, 1);
        SQLiteDatabase bd = admin.getWritableDatabase();
        String numcontrol = ncontrol.getText().toString();
        String nombre = name.getText().toString();
        String semestre = semester.getText().toString();
        String carrera = career.getText().toString();

        ContentValues registro = new ContentValues(); //es una pila
        registro.put("ncontrol", numcontrol);
        registro.put("name", nombre);
        registro.put("semester", semestre);
        registro.put("career", carrera);
        bd.insert("alumno", null, registro);
        bd.close();


        Toast.makeText(this, "Datos del usuario cargados", Toast.LENGTH_SHORT).show();
        this.limpia();
    }

    public void limpia() {
        ncontrol.setText("");
        name.setText("");
        semester.setText("");
        career.setText("");

    }

    public void limpiar(View view) {

        this.limpia();

    }

    public void consulta(View view) {
        AdminSQLiteOpenHelper admin = new
                AdminSQLiteOpenHelper(this, "administracion", null, 1);
        SQLiteDatabase bd = admin.getWritableDatabase();
        String numcontrol = ncontrol.getText().toString();
        Toast.makeText(this, "ESTOY AQUI" + numcontrol, Toast.LENGTH_SHORT).show();
        // Cursor fila = bd.rawQuery("select nombre, semestre, carrera from alumno where numcontrol=" + numcontrol, null);
        Cursor fila = bd.rawQuery("select nombre, semestre, carrera from usuario", null);
        if (fila.moveToFirst()) {
            name.setText(fila.getString(0));
            semester.setText(fila.getString(1));
            career.setText(fila.getString(2));
        } else {
            Toast.makeText(this, "No existe ningún alumno con ese número de control", Toast.LENGTH_SHORT).show();

        }
        bd.close();

    }

    public void baja(View view) {
        AdminSQLiteOpenHelper admin = new
                AdminSQLiteOpenHelper(this, "administracion", null, 1);
        SQLiteDatabase bd = admin.getWritableDatabase();
        String numcontrol = ncontrol.getText().toString();
        // aquí borro la base de datos del usuario por el dni
        int cant = bd.delete("alumno", "numcontrol=" + numcontrol, null);
        bd.close();
        ncontrol.setText("");
        name.setText("");
        semester.setText("");
        career.setText("");
        if (cant == 1) {
            Toast.makeText(this, "Usuario eliminado",
                    Toast.LENGTH_SHORT).show();
        }else {
            Toast.makeText(this, "No existe usuario",
                    Toast.LENGTH_SHORT).show();
        }
    }


}


